import React, {useState} from 'react'
import NavigationBar from './NavigationBar'

const Inventory = () => {
    return (
        <div>
          <NavigationBar />
          <br></br>
          <br></br>
          <br></br>
            <p>
                This is the inventory page
            </p>
        </div>
    )
}

export default Inventory