#!/bin/bash
git pull origin main;
pip3 install -r requirements.txt;
cd backend;
cd frontend;
npm i;